import { TdChatInputProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    autofocus: BooleanConstructor;
    autosize: {
        type: PropType<TdChatInputProps["autosize"]>;
        default: TdChatInputProps["autosize"];
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    stopDisabled: BooleanConstructor;
    suffixIcon: {
        type: PropType<TdChatInputProps["suffixIcon"]>;
    };
    value: {
        type: PropType<TdChatInputProps["value"]>;
        default: TdChatInputProps["value"];
    };
    modelValue: {
        type: PropType<TdChatInputProps["value"]>;
        default: TdChatInputProps["value"];
    };
    defaultValue: {
        type: PropType<TdChatInputProps["defaultValue"]>;
    };
    onBlur: PropType<TdChatInputProps["onBlur"]>;
    onChange: PropType<TdChatInputProps["onChange"]>;
    onFocus: PropType<TdChatInputProps["onFocus"]>;
    onSend: PropType<TdChatInputProps["onSend"]>;
    onStop: PropType<TdChatInputProps["onStop"]>;
};
export default _default;

declare const _default: import("vue").DefineComponent<{
    autofocus: BooleanConstructor;
    autosize: {
        type: import("vue").PropType<import("..").TdChatInputProps["autosize"]>;
        default: import("..").TdChatInputProps["autosize"];
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    stopDisabled: BooleanConstructor;
    suffixIcon: {
        type: import("vue").PropType<import("..").TdChatInputProps["suffixIcon"]>;
    };
    value: {
        type: import("vue").PropType<import("..").TdChatInputProps["value"]>;
        default: import("..").TdChatInputProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<import("..").TdChatInputProps["value"]>;
        default: import("..").TdChatInputProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<import("..").TdChatInputProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<import("..").TdChatInputProps["onBlur"]>;
    onChange: import("vue").PropType<import("..").TdChatInputProps["onChange"]>;
    onFocus: import("vue").PropType<import("..").TdChatInputProps["onFocus"]>;
    onSend: import("vue").PropType<import("..").TdChatInputProps["onSend"]>;
    onStop: import("vue").PropType<import("..").TdChatInputProps["onStop"]>;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "update:modelValue")[], "focus" | "blur" | "stop" | "send" | "update:modelValue", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    autofocus: BooleanConstructor;
    autosize: {
        type: import("vue").PropType<import("..").TdChatInputProps["autosize"]>;
        default: import("..").TdChatInputProps["autosize"];
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    stopDisabled: BooleanConstructor;
    suffixIcon: {
        type: import("vue").PropType<import("..").TdChatInputProps["suffixIcon"]>;
    };
    value: {
        type: import("vue").PropType<import("..").TdChatInputProps["value"]>;
        default: import("..").TdChatInputProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<import("..").TdChatInputProps["value"]>;
        default: import("..").TdChatInputProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<import("..").TdChatInputProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<import("..").TdChatInputProps["onBlur"]>;
    onChange: import("vue").PropType<import("..").TdChatInputProps["onChange"]>;
    onFocus: import("vue").PropType<import("..").TdChatInputProps["onFocus"]>;
    onSend: import("vue").PropType<import("..").TdChatInputProps["onSend"]>;
    onStop: import("vue").PropType<import("..").TdChatInputProps["onStop"]>;
}>> & {
    onFocus?: (...args: any[]) => any;
    onBlur?: (...args: any[]) => any;
    onSend?: (...args: any[]) => any;
    onStop?: (...args: any[]) => any;
    "onUpdate:modelValue"?: (...args: any[]) => any;
}, {
    disabled: boolean;
    value: string;
    placeholder: string;
    modelValue: string;
    autofocus: boolean;
    autosize: boolean | {
        minRows?: number;
        maxRows?: number;
    };
    stopDisabled: boolean;
}, {}>;
export default _default;

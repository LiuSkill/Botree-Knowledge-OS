import { AvatarProps } from 'tdesign-vue-next';
import { TextareaProps } from 'tdesign-vue-next';
import { CollapsePanelProps } from 'tdesign-vue-next';
import { TNode } from 'tdesign-vue-next';
import { AIMessageContent, ChatMessageRole, ChatMessageStatus, UserMessageContent } from 'tdesign-web-components';
export interface TdChatProps {
    actions?: TNode;
    actionbar?: TNode;
    autoScroll?: boolean;
    defaultScrollTo?: 'top' | 'bottom';
    animation?: 'skeleton' | 'moving' | 'gradient';
    avatar?: TNode<{
        item: TdChatItemProps;
        index: number;
    }>;
    clearHistory?: boolean;
    content?: TNode<{
        item: TdChatItemProps;
        index: number;
    }>;
    data?: Array<TdChatItemMeta>;
    datetime?: TNode<{
        item: TdChatItemProps;
        index: number;
    }>;
    isStreamLoad?: boolean;
    layout?: 'both' | 'single';
    name?: TNode<{
        item: TdChatItemProps;
        index: number;
    }>;
    reasoning?: TNode<{
        item: TdChatItemProps;
        index: number;
    }>;
    reverse?: boolean;
    showScrollButton?: boolean;
    textLoading?: boolean;
    onClear?: (context: {
        e: MouseEvent;
    }) => void;
    onScroll?: (context: {
        e: MouseEvent;
    }) => void;
}
export interface ChatInstanceFunctions {
    scrollToBottom?: (params?: ScrollToBottomParams) => void;
}
export interface TdChatLoadingProps {
    animation?: 'moving' | 'gradient';
    text?: string;
}
export interface TdChatItemProps {
    actions?: string | TNode;
    actionbar?: string | TNode;
    animation?: 'skeleton' | 'moving' | 'gradient';
    avatar?: String | AvatarProps | TNode;
    content?: string | TNode;
    datetime?: string | TNode;
    name?: string | TNode;
    reasoning?: boolean | TdChatReasoning;
    role?: 'user' | 'assistant' | 'error' | 'model-change' | 'system';
    textLoading?: boolean;
    variant?: 'base' | 'outline' | 'text';
    status?: '' | 'error';
}
type ChatContentType = 'text' | 'markdown';
export interface ChatContentData {
    type: ChatContentType;
    data: any;
}
export interface TdChatContentProps {
    content?: string | ChatContentData;
    role?: 'user' | 'assistant' | 'model-change' | 'system';
    markdownProps?: {
        engine: 'marked' | 'cherry-markdown';
        options: {
            [key: string]: any;
        };
    };
    status?: '' | 'error';
}
export interface TdChatActionProps {
    content?: string;
    disabled?: boolean;
    comment?: 'good' | 'bad' | '';
    isBad?: boolean;
    isGood?: boolean;
    actionBar?: Array<'replay' | 'copy' | 'good' | 'bad' | 'share'>;
    operationBtn?: Array<'replay' | 'copy' | 'good' | 'bad' | 'share'>;
    onActions?: (value: string, context: {
        e: MouseEvent;
    }) => void;
    onOperation?: (value: string, context: {
        e: MouseEvent;
    }) => void;
}
export interface TdChatInputProps {
    autofocus?: boolean;
    autosize?: boolean | {
        minRows?: number;
        maxRows?: number;
    };
    disabled?: boolean;
    placeholder?: string;
    stopDisabled?: boolean;
    suffixIcon?: TNode;
    value?: string;
    defaultValue?: string;
    modelValue?: string;
    onBlur?: (value: string, context: {
        e: FocusEvent;
    }) => void;
    onChange?: (value: string, context: {
        e: InputEvent | MouseEvent | KeyboardEvent;
    }) => void;
    onFocus?: (value: string, context: {
        e: FocusEvent;
    }) => void;
    onSend?: (value: string, context: {
        e: MouseEvent | KeyboardEvent;
    }) => void;
    onStop?: (value: string, context: {
        e: MouseEvent;
    }) => void;
}
export interface TdChatSenderProps {
    disabled?: boolean;
    sendBtnDisabled?: boolean;
    placeholder?: string;
    footerPrefix?: string | TNode;
    stopDisabled?: boolean;
    loading: boolean;
    suffix?: string | TNode;
    textareaProps?: TextareaProps;
    value?: string;
    defaultValue?: string;
    modelValue?: string;
    onBlur?: (value: string, context: {
        e: FocusEvent;
    }) => void;
    onChange?: (value: string, context: {
        e: InputEvent | MouseEvent | KeyboardEvent;
    }) => void;
    onFocus?: (value: string, context: {
        e: FocusEvent;
    }) => void;
    onSend?: (value: string, context: {
        e: MouseEvent | KeyboardEvent;
    }) => void;
    onStop?: (value: string, context: {
        e: MouseEvent;
    }) => void;
    attachmentsProps?: {
        items: any[];
        overflow: 'scrollX' | 'scrollY' | 'wrap';
    };
}
export interface TdChatReasoningProps {
    collapsePanelProps?: CollapsePanelProps;
    expandIcon?: TNode;
    expandIconPlacement?: 'left' | 'right';
    header?: TNode;
    headerRightContent?: TNode;
    onExpandChange?: (value: boolean) => void;
    collapsed?: boolean;
    layout?: 'border' | 'block';
    animation?: 'moving' | 'gradient' | 'circle';
}
export interface TdChatItemMeta {
    avatar?: string;
    name?: string;
    role?: ChatMessageRole;
    datetime?: string;
    content?: AIMessageContent[] | UserMessageContent[];
    status?: ChatMessageStatus;
}
export type ScrollToBottomParams = {
    behavior: 'auto' | 'smooth';
};
export interface TdChatReasoning {
    expandIconPlacement?: 'left' | 'right';
    onExpandChange?: (isExpand: boolean) => void;
    collapsePanelProps?: Object;
    collapsed?: boolean;
}
export type UploadActionType = 'uploadAttachment' | 'uploadImage';
export interface UploadActionConfig {
    name: UploadActionType;
    uploadProps?: {
        multiple?: boolean;
        accept?: string;
    };
    action: (params: {
        files: File[];
        name: UploadActionType;
        e?: Event;
    }) => void;
}
export type * from 'tdesign-web-components/lib/chat-sender/type';
export type * from 'tdesign-web-components/lib/filecard/type';
export type * from 'tdesign-web-components/lib/chat-message/index';
export type * from 'tdesign-web-components/lib/chatbot/type';
export type * from 'tdesign-web-components/lib/chat-action/type';

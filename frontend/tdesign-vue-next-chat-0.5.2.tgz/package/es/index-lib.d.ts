import './style';
import TDesignChat from './index';
export * from './index';
export default TDesignChat;

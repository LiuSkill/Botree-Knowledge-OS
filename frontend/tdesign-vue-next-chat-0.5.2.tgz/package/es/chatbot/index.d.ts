import 'tdesign-web-components/lib/chatbot';
import type { DefineComponent } from 'vue';
import type { TdChatListProps, TdChatProps, TdChatSearchContentProps, TdChatSuggestionContentProps } from 'tdesign-web-components';
export declare const Chatbot: DefineComponent<TdChatProps>;
export declare const ChatSearchContentComponent: DefineComponent<TdChatSearchContentProps>;
export declare const ChatSuggestionContentComponent: DefineComponent<TdChatSuggestionContentProps>;
export declare const ChatListComponent: DefineComponent<TdChatListProps>;
export default Chatbot;

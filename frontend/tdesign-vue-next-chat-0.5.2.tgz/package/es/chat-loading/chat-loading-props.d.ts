import { TdChatLoadingProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    animation: {
        type: PropType<TdChatLoadingProps["animation"]>;
        default: TdChatLoadingProps["animation"];
        validator(val: TdChatLoadingProps["animation"]): boolean;
    };
    text: {
        type: StringConstructor;
        default: string;
    };
};
export default _default;

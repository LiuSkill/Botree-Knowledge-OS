import { TdChatLoadingProps } from 'tdesign-web-components';
import 'tdesign-web-components/lib/chat-loading';
import type { DefineComponent } from 'vue';
export declare const ChatLoading: DefineComponent<TdChatLoadingProps>;
export default ChatLoading;

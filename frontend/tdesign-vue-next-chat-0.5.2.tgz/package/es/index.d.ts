import { App } from 'vue';
import { ToolCallRenderer } from './chat-engine/components/toolcall';
export * from './chat-engine';
import { TdChatProps, TdChatItemProps, TdChatContentProps, TdChatActionProps, TdChatInputProps, TdChatSenderProps, TdChatReasoningProps, TdChatLoadingProps } from './type';
import './style';
import 'tdesign-web-components/lib/style/index.css';
import 'tdesign-web-components/lib/chat-message/content/search-content';
import 'tdesign-web-components/lib/chat-message/content/suggestion-content';
import { TdMarkdownEngine } from 'tdesign-web-components/lib/chat-message';
export * from './type';
export type ChatProps = TdChatProps;
export type ChatItemProps = TdChatItemProps;
export type ChatContentProps = TdChatContentProps;
export type ChatActionProps = TdChatActionProps;
export type ChatInputProps = TdChatInputProps;
export type ChatSenderProps = TdChatSenderProps;
export type ChatReasoningProps = TdChatReasoningProps;
export type ChatLoadingProps = TdChatLoadingProps;
export declare const ChatList: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("scroll" | "clear")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, {
        reverse: boolean;
        layout: "single" | "both";
        animation: "skeleton" | "gradient" | "moving";
        defaultScrollTo: "top" | "bottom";
        showScrollButton: boolean;
        autoScroll: boolean;
        clearHistory: boolean;
        isStreamLoad: boolean;
        textLoading: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        reverse: boolean;
        layout: "single" | "both";
        animation: "skeleton" | "gradient" | "moving";
        defaultScrollTo: "top" | "bottom";
        showScrollButton: boolean;
        autoScroll: boolean;
        clearHistory: boolean;
        isStreamLoad: boolean;
        textLoading: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    actions: {
        type: import("vue").PropType<TdChatProps["actions"]>;
    };
    actionbar: {
        type: import("vue").PropType<TdChatProps["actionbar"]>;
    };
    autoScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    defaultScrollTo: {
        type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
        default: TdChatProps["defaultScrollTo"];
        validator(val: TdChatProps["defaultScrollTo"]): boolean;
    };
    animation: {
        type: import("vue").PropType<TdChatProps["animation"]>;
        default: TdChatProps["animation"];
        validator(val: TdChatProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<TdChatProps["avatar"]>;
    };
    clearHistory: {
        type: BooleanConstructor;
        default: boolean;
    };
    content: {
        type: import("vue").PropType<TdChatProps["content"]>;
    };
    data: {
        type: import("vue").PropType<TdChatProps["data"]>;
    };
    datetime: {
        type: import("vue").PropType<TdChatProps["datetime"]>;
    };
    isStreamLoad: BooleanConstructor;
    layout: {
        type: import("vue").PropType<TdChatProps["layout"]>;
        default: TdChatProps["layout"];
        validator(val: TdChatProps["layout"]): boolean;
    };
    name: {
        type: import("vue").PropType<TdChatProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<TdChatProps["reasoning"]>;
    };
    reverse: {
        type: BooleanConstructor;
        default: boolean;
    };
    showScrollButton: {
        type: import("vue").PropType<TdChatProps["showScrollButton"]>;
        default: boolean;
    };
    textLoading: BooleanConstructor;
    onClear: import("vue").PropType<TdChatProps["onClear"]>;
    onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
}>> & {
    onScroll?: (...args: any[]) => any;
    onClear?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("scroll" | "clear")[], "scroll" | "clear", {
    reverse: boolean;
    layout: "single" | "both";
    animation: "skeleton" | "gradient" | "moving";
    defaultScrollTo: "top" | "bottom";
    showScrollButton: boolean;
    autoScroll: boolean;
    clearHistory: boolean;
    isStreamLoad: boolean;
    textLoading: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatSender: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        attachmentsProps: {
            type: ObjectConstructor;
            default: () => {
                items: any[];
                overflow: string;
            };
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        footerPrefix: {
            type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
        };
        stopDisabled: {
            type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
            default: boolean;
        };
        sendBtnDisabled: {
            type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
            default: boolean;
        };
        loading: {
            type: import("vue").PropType<TdChatSenderProps["loading"]>;
            default: boolean;
        };
        suffix: {
            type: import("vue").PropType<TdChatSenderProps["suffix"]>;
        };
        textareaProps: {
            type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
        };
        value: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
        onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onRemove?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
        onFileClick?: (...args: any[]) => any;
        onFileSelect?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "remove" | "update:modelValue" | "fileSelect" | "fileClick")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        attachmentsProps: {
            type: ObjectConstructor;
            default: () => {
                items: any[];
                overflow: string;
            };
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        footerPrefix: {
            type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
        };
        stopDisabled: {
            type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
            default: boolean;
        };
        sendBtnDisabled: {
            type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
            default: boolean;
        };
        loading: {
            type: import("vue").PropType<TdChatSenderProps["loading"]>;
            default: boolean;
        };
        suffix: {
            type: import("vue").PropType<TdChatSenderProps["suffix"]>;
        };
        textareaProps: {
            type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
        };
        value: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
        onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onRemove?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
        onFileClick?: (...args: any[]) => any;
        onFileSelect?: (...args: any[]) => any;
    }, {
        disabled: boolean;
        value: string;
        loading: boolean;
        placeholder: string;
        modelValue: string;
        stopDisabled: boolean;
        sendBtnDisabled: boolean;
        attachmentsProps: Record<string, any>;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        attachmentsProps: {
            type: ObjectConstructor;
            default: () => {
                items: any[];
                overflow: string;
            };
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        footerPrefix: {
            type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
        };
        stopDisabled: {
            type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
            default: boolean;
        };
        sendBtnDisabled: {
            type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
            default: boolean;
        };
        loading: {
            type: import("vue").PropType<TdChatSenderProps["loading"]>;
            default: boolean;
        };
        suffix: {
            type: import("vue").PropType<TdChatSenderProps["suffix"]>;
        };
        textareaProps: {
            type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
        };
        value: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatSenderProps["value"]>;
            default: TdChatSenderProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
        onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onRemove?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
        onFileClick?: (...args: any[]) => any;
        onFileSelect?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        disabled: boolean;
        value: string;
        loading: boolean;
        placeholder: string;
        modelValue: string;
        stopDisabled: boolean;
        sendBtnDisabled: boolean;
        attachmentsProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    attachmentsProps: {
        type: ObjectConstructor;
        default: () => {
            items: any[];
            overflow: string;
        };
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    footerPrefix: {
        type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
    };
    stopDisabled: {
        type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
        default: boolean;
    };
    sendBtnDisabled: {
        type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
        default: boolean;
    };
    loading: {
        type: import("vue").PropType<TdChatSenderProps["loading"]>;
        default: boolean;
    };
    suffix: {
        type: import("vue").PropType<TdChatSenderProps["suffix"]>;
    };
    textareaProps: {
        type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
    };
    value: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
    onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
    onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
    onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
    onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
}>> & {
    onFocus?: (...args: any[]) => any;
    onBlur?: (...args: any[]) => any;
    onRemove?: (...args: any[]) => any;
    onSend?: (...args: any[]) => any;
    onStop?: (...args: any[]) => any;
    "onUpdate:modelValue"?: (...args: any[]) => any;
    onFileClick?: (...args: any[]) => any;
    onFileSelect?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "remove" | "update:modelValue" | "fileSelect" | "fileClick")[], "focus" | "blur" | "stop" | "send" | "remove" | "update:modelValue" | "fileSelect" | "fileClick", {
    disabled: boolean;
    value: string;
    loading: boolean;
    placeholder: string;
    modelValue: string;
    stopDisabled: boolean;
    sendBtnDisabled: boolean;
    attachmentsProps: Record<string, any>;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatActionbar: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("operation" | "actions")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, {
        disabled: boolean;
        comment: "" | "good" | "bad";
        content: string;
        actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
        operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
        isBad: boolean;
        isGood: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        disabled: boolean;
        comment: "" | "good" | "bad";
        content: string;
        actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
        operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
        isBad: boolean;
        isGood: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    content: {
        type: StringConstructor;
        default: string;
    };
    disabled: BooleanConstructor;
    comment: {
        type: import("vue").PropType<"good" | "bad" | "">;
        validator: (value: string) => boolean;
        default: string;
    };
    isBad: {
        type: BooleanConstructor;
        default: boolean;
    };
    isGood: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionBar: {
        type: import("vue").PropType<TdChatActionProps["actionBar"]>;
        default: () => TdChatActionProps["actionBar"];
    };
    operationBtn: {
        type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
        default: () => TdChatActionProps["operationBtn"];
    };
    onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
    onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
}>> & {
    onActions?: (...args: any[]) => any;
    onOperation?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("operation" | "actions")[], "operation" | "actions", {
    disabled: boolean;
    comment: "" | "good" | "bad";
    content: string;
    actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
    operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
    isBad: boolean;
    isGood: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatLoading: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdChatLoadingProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdChatLoadingProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdChatLoadingProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdChatLoadingProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const Attachments: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdAttachmentsProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdAttachmentsProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdAttachmentsProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdAttachmentsProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatThinking: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        layout: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["layout"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["layout"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["layout"]): boolean;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["status"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["status"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["status"]): boolean;
        };
        maxHeight: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["maxHeight"]>;
        };
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["animation"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["animation"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["animation"]): boolean;
        };
        content: {
            type: import("vue").PropType<import("@src/common").TNode>;
        };
        collapsed: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["collapsed"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["collapsed"];
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        layout: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["layout"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["layout"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["layout"]): boolean;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["status"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["status"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["status"]): boolean;
        };
        maxHeight: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["maxHeight"]>;
        };
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["animation"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["animation"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["animation"]): boolean;
        };
        content: {
            type: import("vue").PropType<import("@src/common").TNode>;
        };
        collapsed: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["collapsed"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["collapsed"];
        };
    }>>, {
        layout: "block" | "border";
        status: import("tdesign-web-components").ChatMessageStatus;
        animation: import("tdesign-web-components").ChatLoadingAnimationType;
        collapsed: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        layout: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["layout"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["layout"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["layout"]): boolean;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["status"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["status"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["status"]): boolean;
        };
        maxHeight: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["maxHeight"]>;
        };
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["animation"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["animation"];
            validator(val: import("tdesign-web-components").TdChatThinkContentProps["animation"]): boolean;
        };
        content: {
            type: import("vue").PropType<import("@src/common").TNode>;
        };
        collapsed: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["collapsed"]>;
            default: import("tdesign-web-components").TdChatThinkContentProps["collapsed"];
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        layout: "block" | "border";
        status: import("tdesign-web-components").ChatMessageStatus;
        animation: import("tdesign-web-components").ChatLoadingAnimationType;
        collapsed: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    layout: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["layout"]>;
        default: import("tdesign-web-components").TdChatThinkContentProps["layout"];
        validator(val: import("tdesign-web-components").TdChatThinkContentProps["layout"]): boolean;
    };
    status: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["status"]>;
        default: import("tdesign-web-components").TdChatThinkContentProps["status"];
        validator(val: import("tdesign-web-components").TdChatThinkContentProps["status"]): boolean;
    };
    maxHeight: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["maxHeight"]>;
    };
    animation: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["animation"]>;
        default: import("tdesign-web-components").TdChatThinkContentProps["animation"];
        validator(val: import("tdesign-web-components").TdChatThinkContentProps["animation"]): boolean;
    };
    content: {
        type: import("vue").PropType<import("@src/common").TNode>;
    };
    collapsed: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatThinkContentProps["collapsed"]>;
        default: import("tdesign-web-components").TdChatThinkContentProps["collapsed"];
    };
}>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    layout: "block" | "border";
    status: import("tdesign-web-components").ChatMessageStatus;
    animation: import("tdesign-web-components").ChatLoadingAnimationType;
    collapsed: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const Chatbot: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdChatProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdChatProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdChatProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdChatProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatMessage: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["animation"]>;
            default: import("tdesign-web-components").TdChatMessageProps["animation"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["avatar"]>;
        };
        datetime: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["datetime"]>;
        };
        role: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["role"]>;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["status"]>;
        };
        content: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["content"]>;
        };
        name: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["name"]>;
        };
        variant: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["variant"]>;
            default: import("tdesign-web-components").TdChatMessageProps["variant"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["variant"]): boolean;
        };
        message: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["message"]>;
        };
        placement: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["placement"]>;
            default: import("tdesign-web-components").TdChatMessageProps["placement"];
        };
        chatContentProps: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["chatContentProps"]>;
        };
        allowContentSegmentCustom: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["animation"]>;
            default: import("tdesign-web-components").TdChatMessageProps["animation"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["avatar"]>;
        };
        datetime: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["datetime"]>;
        };
        role: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["role"]>;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["status"]>;
        };
        content: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["content"]>;
        };
        name: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["name"]>;
        };
        variant: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["variant"]>;
            default: import("tdesign-web-components").TdChatMessageProps["variant"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["variant"]): boolean;
        };
        message: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["message"]>;
        };
        placement: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["placement"]>;
            default: import("tdesign-web-components").TdChatMessageProps["placement"];
        };
        chatContentProps: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["chatContentProps"]>;
        };
        allowContentSegmentCustom: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, {
        animation: import("tdesign-web-components").ChatLoadingAnimationType;
        variant: import("tdesign-web-components").TdChatMessageVariant;
        placement: "left" | "right";
        allowContentSegmentCustom: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        animation: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["animation"]>;
            default: import("tdesign-web-components").TdChatMessageProps["animation"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["avatar"]>;
        };
        datetime: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["datetime"]>;
        };
        role: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["role"]>;
        };
        status: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["status"]>;
        };
        content: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["content"]>;
        };
        name: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["name"]>;
        };
        variant: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["variant"]>;
            default: import("tdesign-web-components").TdChatMessageProps["variant"];
            validator(val: import("tdesign-web-components").TdChatMessageProps["variant"]): boolean;
        };
        message: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["message"]>;
        };
        placement: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["placement"]>;
            default: import("tdesign-web-components").TdChatMessageProps["placement"];
        };
        chatContentProps: {
            type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["chatContentProps"]>;
        };
        allowContentSegmentCustom: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        animation: import("tdesign-web-components").ChatLoadingAnimationType;
        variant: import("tdesign-web-components").TdChatMessageVariant;
        placement: "left" | "right";
        allowContentSegmentCustom: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    animation: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["animation"]>;
        default: import("tdesign-web-components").TdChatMessageProps["animation"];
        validator(val: import("tdesign-web-components").TdChatMessageProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["avatar"]>;
    };
    datetime: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["datetime"]>;
    };
    role: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["role"]>;
    };
    status: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["status"]>;
    };
    content: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["content"]>;
    };
    name: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["name"]>;
    };
    variant: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["variant"]>;
        default: import("tdesign-web-components").TdChatMessageProps["variant"];
        validator(val: import("tdesign-web-components").TdChatMessageProps["variant"]): boolean;
    };
    message: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["message"]>;
    };
    placement: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["placement"]>;
        default: import("tdesign-web-components").TdChatMessageProps["placement"];
    };
    chatContentProps: {
        type: import("vue").PropType<import("tdesign-web-components").TdChatMessageProps["chatContentProps"]>;
    };
    allowContentSegmentCustom: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    animation: import("tdesign-web-components").ChatLoadingAnimationType;
    variant: import("tdesign-web-components").TdChatMessageVariant;
    placement: "left" | "right";
    allowContentSegmentCustom: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatContent: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: import("vue").PropType<TdChatContentProps["content"]>;
            default: string;
        };
        role: {
            type: import("vue").PropType<TdChatContentProps["role"]>;
            validator(val: TdChatContentProps["role"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatContentProps["status"]>;
            default: string;
        };
        markdownProps: {
            type: import("vue").PropType<TdChatContentProps["markdownProps"]>;
            default: () => {
                engine: string;
                options: {};
            };
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: import("vue").PropType<TdChatContentProps["content"]>;
            default: string;
        };
        role: {
            type: import("vue").PropType<TdChatContentProps["role"]>;
            validator(val: TdChatContentProps["role"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatContentProps["status"]>;
            default: string;
        };
        markdownProps: {
            type: import("vue").PropType<TdChatContentProps["markdownProps"]>;
            default: () => {
                engine: string;
                options: {};
            };
        };
    }>>, {
        status: "" | "error";
        content: string | import("./type").ChatContentData;
        markdownProps: {
            engine: "marked" | "cherry-markdown";
            options: {
                [key: string]: any;
            };
        };
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: import("vue").PropType<TdChatContentProps["content"]>;
            default: string;
        };
        role: {
            type: import("vue").PropType<TdChatContentProps["role"]>;
            validator(val: TdChatContentProps["role"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatContentProps["status"]>;
            default: string;
        };
        markdownProps: {
            type: import("vue").PropType<TdChatContentProps["markdownProps"]>;
            default: () => {
                engine: string;
                options: {};
            };
        };
    }>>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        status: "" | "error";
        content: string | import("./type").ChatContentData;
        markdownProps: {
            engine: "marked" | "cherry-markdown";
            options: {
                [key: string]: any;
            };
        };
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    content: {
        type: import("vue").PropType<TdChatContentProps["content"]>;
        default: string;
    };
    role: {
        type: import("vue").PropType<TdChatContentProps["role"]>;
        validator(val: TdChatContentProps["role"]): boolean;
    };
    status: {
        type: import("vue").PropType<TdChatContentProps["status"]>;
        default: string;
    };
    markdownProps: {
        type: import("vue").PropType<TdChatContentProps["markdownProps"]>;
        default: () => {
            engine: string;
            options: {};
        };
    };
}>>, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    status: "" | "error";
    content: string | import("./type").ChatContentData;
    markdownProps: {
        engine: "marked" | "cherry-markdown";
        options: {
            [key: string]: any;
        };
    };
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatSearchContent: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdChatSearchContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdChatSearchContentProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdChatSearchContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdChatSearchContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatSuggestionContent: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdChatSuggestionContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdChatSuggestionContentProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdChatSuggestionContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdChatSuggestionContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatMarkdown: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("tdesign-web-components").TdChatMarkdownContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("tdesign-web-components").TdChatMarkdownContentProps>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("tdesign-web-components").TdChatMarkdownContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("tdesign-web-components").TdChatMarkdownContentProps>, {}, {}, import("vue").ComputedOptions, import("vue").MethodOptions, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const Chat: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("scroll" | "clear")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, {
        reverse: boolean;
        layout: "single" | "both";
        animation: "skeleton" | "gradient" | "moving";
        defaultScrollTo: "top" | "bottom";
        showScrollButton: boolean;
        autoScroll: boolean;
        clearHistory: boolean;
        isStreamLoad: boolean;
        textLoading: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<TdChatProps["actions"]>;
        };
        actionbar: {
            type: import("vue").PropType<TdChatProps["actionbar"]>;
        };
        autoScroll: {
            type: BooleanConstructor;
            default: boolean;
        };
        defaultScrollTo: {
            type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
            default: TdChatProps["defaultScrollTo"];
            validator(val: TdChatProps["defaultScrollTo"]): boolean;
        };
        animation: {
            type: import("vue").PropType<TdChatProps["animation"]>;
            default: TdChatProps["animation"];
            validator(val: TdChatProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatProps["avatar"]>;
        };
        clearHistory: {
            type: BooleanConstructor;
            default: boolean;
        };
        content: {
            type: import("vue").PropType<TdChatProps["content"]>;
        };
        data: {
            type: import("vue").PropType<TdChatProps["data"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatProps["datetime"]>;
        };
        isStreamLoad: BooleanConstructor;
        layout: {
            type: import("vue").PropType<TdChatProps["layout"]>;
            default: TdChatProps["layout"];
            validator(val: TdChatProps["layout"]): boolean;
        };
        name: {
            type: import("vue").PropType<TdChatProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatProps["reasoning"]>;
        };
        reverse: {
            type: BooleanConstructor;
            default: boolean;
        };
        showScrollButton: {
            type: import("vue").PropType<TdChatProps["showScrollButton"]>;
            default: boolean;
        };
        textLoading: BooleanConstructor;
        onClear: import("vue").PropType<TdChatProps["onClear"]>;
        onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
    }>> & {
        onScroll?: (...args: any[]) => any;
        onClear?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        reverse: boolean;
        layout: "single" | "both";
        animation: "skeleton" | "gradient" | "moving";
        defaultScrollTo: "top" | "bottom";
        showScrollButton: boolean;
        autoScroll: boolean;
        clearHistory: boolean;
        isStreamLoad: boolean;
        textLoading: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    actions: {
        type: import("vue").PropType<TdChatProps["actions"]>;
    };
    actionbar: {
        type: import("vue").PropType<TdChatProps["actionbar"]>;
    };
    autoScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    defaultScrollTo: {
        type: import("vue").PropType<TdChatProps["defaultScrollTo"]>;
        default: TdChatProps["defaultScrollTo"];
        validator(val: TdChatProps["defaultScrollTo"]): boolean;
    };
    animation: {
        type: import("vue").PropType<TdChatProps["animation"]>;
        default: TdChatProps["animation"];
        validator(val: TdChatProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<TdChatProps["avatar"]>;
    };
    clearHistory: {
        type: BooleanConstructor;
        default: boolean;
    };
    content: {
        type: import("vue").PropType<TdChatProps["content"]>;
    };
    data: {
        type: import("vue").PropType<TdChatProps["data"]>;
    };
    datetime: {
        type: import("vue").PropType<TdChatProps["datetime"]>;
    };
    isStreamLoad: BooleanConstructor;
    layout: {
        type: import("vue").PropType<TdChatProps["layout"]>;
        default: TdChatProps["layout"];
        validator(val: TdChatProps["layout"]): boolean;
    };
    name: {
        type: import("vue").PropType<TdChatProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<TdChatProps["reasoning"]>;
    };
    reverse: {
        type: BooleanConstructor;
        default: boolean;
    };
    showScrollButton: {
        type: import("vue").PropType<TdChatProps["showScrollButton"]>;
        default: boolean;
    };
    textLoading: BooleanConstructor;
    onClear: import("vue").PropType<TdChatProps["onClear"]>;
    onScroll: import("vue").PropType<TdChatProps["onScroll"]>;
}>> & {
    onScroll?: (...args: any[]) => any;
    onClear?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("scroll" | "clear")[], "scroll" | "clear", {
    reverse: boolean;
    layout: "single" | "both";
    animation: "skeleton" | "gradient" | "moving";
    defaultScrollTo: "top" | "bottom";
    showScrollButton: boolean;
    autoScroll: boolean;
    clearHistory: boolean;
    isStreamLoad: boolean;
    textLoading: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatAction: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("operation" | "actions")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, {
        disabled: boolean;
        comment: "" | "good" | "bad";
        content: string;
        actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
        operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
        isBad: boolean;
        isGood: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        content: {
            type: StringConstructor;
            default: string;
        };
        disabled: BooleanConstructor;
        comment: {
            type: import("vue").PropType<"good" | "bad" | "">;
            validator: (value: string) => boolean;
            default: string;
        };
        isBad: {
            type: BooleanConstructor;
            default: boolean;
        };
        isGood: {
            type: BooleanConstructor;
            default: boolean;
        };
        actionBar: {
            type: import("vue").PropType<TdChatActionProps["actionBar"]>;
            default: () => TdChatActionProps["actionBar"];
        };
        operationBtn: {
            type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
            default: () => TdChatActionProps["operationBtn"];
        };
        onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
        onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
    }>> & {
        onActions?: (...args: any[]) => any;
        onOperation?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        disabled: boolean;
        comment: "" | "good" | "bad";
        content: string;
        actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
        operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
        isBad: boolean;
        isGood: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    content: {
        type: StringConstructor;
        default: string;
    };
    disabled: BooleanConstructor;
    comment: {
        type: import("vue").PropType<"good" | "bad" | "">;
        validator: (value: string) => boolean;
        default: string;
    };
    isBad: {
        type: BooleanConstructor;
        default: boolean;
    };
    isGood: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionBar: {
        type: import("vue").PropType<TdChatActionProps["actionBar"]>;
        default: () => TdChatActionProps["actionBar"];
    };
    operationBtn: {
        type: import("vue").PropType<TdChatActionProps["operationBtn"]>;
        default: () => TdChatActionProps["operationBtn"];
    };
    onActions: import("vue").PropType<TdChatActionProps["onActions"]>;
    onOperation: import("vue").PropType<TdChatActionProps["onOperation"]>;
}>> & {
    onActions?: (...args: any[]) => any;
    onOperation?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("operation" | "actions")[], "operation" | "actions", {
    disabled: boolean;
    comment: "" | "good" | "bad";
    content: string;
    actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
    operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
    isBad: boolean;
    isGood: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatInput: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        autofocus: BooleanConstructor;
        autosize: {
            type: import("vue").PropType<TdChatInputProps["autosize"]>;
            default: TdChatInputProps["autosize"];
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        stopDisabled: BooleanConstructor;
        suffixIcon: {
            type: import("vue").PropType<TdChatInputProps["suffixIcon"]>;
        };
        value: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatInputProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatInputProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatInputProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatInputProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatInputProps["onSend"]>;
        onStop: import("vue").PropType<TdChatInputProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "update:modelValue")[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        autofocus: BooleanConstructor;
        autosize: {
            type: import("vue").PropType<TdChatInputProps["autosize"]>;
            default: TdChatInputProps["autosize"];
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        stopDisabled: BooleanConstructor;
        suffixIcon: {
            type: import("vue").PropType<TdChatInputProps["suffixIcon"]>;
        };
        value: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatInputProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatInputProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatInputProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatInputProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatInputProps["onSend"]>;
        onStop: import("vue").PropType<TdChatInputProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
    }, {
        disabled: boolean;
        value: string;
        placeholder: string;
        modelValue: string;
        autofocus: boolean;
        autosize: boolean | {
            minRows?: number;
            maxRows?: number;
        };
        stopDisabled: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        autofocus: BooleanConstructor;
        autosize: {
            type: import("vue").PropType<TdChatInputProps["autosize"]>;
            default: TdChatInputProps["autosize"];
        };
        disabled: BooleanConstructor;
        placeholder: {
            type: StringConstructor;
            default: string;
        };
        stopDisabled: BooleanConstructor;
        suffixIcon: {
            type: import("vue").PropType<TdChatInputProps["suffixIcon"]>;
        };
        value: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        modelValue: {
            type: import("vue").PropType<TdChatInputProps["value"]>;
            default: TdChatInputProps["value"];
        };
        defaultValue: {
            type: import("vue").PropType<TdChatInputProps["defaultValue"]>;
        };
        onBlur: import("vue").PropType<TdChatInputProps["onBlur"]>;
        onChange: import("vue").PropType<TdChatInputProps["onChange"]>;
        onFocus: import("vue").PropType<TdChatInputProps["onFocus"]>;
        onSend: import("vue").PropType<TdChatInputProps["onSend"]>;
        onStop: import("vue").PropType<TdChatInputProps["onStop"]>;
    }>> & {
        onFocus?: (...args: any[]) => any;
        onBlur?: (...args: any[]) => any;
        onSend?: (...args: any[]) => any;
        onStop?: (...args: any[]) => any;
        "onUpdate:modelValue"?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        disabled: boolean;
        value: string;
        placeholder: string;
        modelValue: string;
        autofocus: boolean;
        autosize: boolean | {
            minRows?: number;
            maxRows?: number;
        };
        stopDisabled: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    autofocus: BooleanConstructor;
    autosize: {
        type: import("vue").PropType<TdChatInputProps["autosize"]>;
        default: TdChatInputProps["autosize"];
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    stopDisabled: BooleanConstructor;
    suffixIcon: {
        type: import("vue").PropType<TdChatInputProps["suffixIcon"]>;
    };
    value: {
        type: import("vue").PropType<TdChatInputProps["value"]>;
        default: TdChatInputProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<TdChatInputProps["value"]>;
        default: TdChatInputProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<TdChatInputProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<TdChatInputProps["onBlur"]>;
    onChange: import("vue").PropType<TdChatInputProps["onChange"]>;
    onFocus: import("vue").PropType<TdChatInputProps["onFocus"]>;
    onSend: import("vue").PropType<TdChatInputProps["onSend"]>;
    onStop: import("vue").PropType<TdChatInputProps["onStop"]>;
}>> & {
    onFocus?: (...args: any[]) => any;
    onBlur?: (...args: any[]) => any;
    onSend?: (...args: any[]) => any;
    onStop?: (...args: any[]) => any;
    "onUpdate:modelValue"?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "update:modelValue")[], "focus" | "blur" | "stop" | "send" | "update:modelValue", {
    disabled: boolean;
    value: string;
    placeholder: string;
    modelValue: string;
    autofocus: boolean;
    autosize: boolean | {
        minRows?: number;
        maxRows?: number;
    };
    stopDisabled: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatReasoning: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        collapsePanelProps: {
            type: import("vue").PropType<TdChatReasoningProps["collapsePanelProps"]>;
            default: () => TdChatReasoningProps["collapsePanelProps"];
        };
        expandIcon: {
            type: import("vue").PropType<TdChatReasoningProps["expandIcon"]>;
        };
        expandIconPlacement: {
            type: import("vue").PropType<TdChatReasoningProps["expandIconPlacement"]>;
            default: TdChatReasoningProps["expandIconPlacement"];
            validator(val: TdChatReasoningProps["expandIconPlacement"]): boolean;
        };
        header: {
            type: import("vue").PropType<TdChatReasoningProps["header"]>;
        };
        headerRightContent: {
            type: import("vue").PropType<TdChatReasoningProps["headerRightContent"]>;
        };
        onExpandChange: {
            type: import("vue").PropType<TdChatReasoningProps["onExpandChange"]>;
            default: () => void;
        };
        collapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        modelValue: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: TdChatReasoningProps["collapsed"];
        };
        defaultCollapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        layout: {
            type: import("vue").PropType<TdChatReasoningProps["layout"]>;
            default: string;
        };
    }>> & {
        "onUpdate:collapsed"?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "update:collapsed"[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        collapsePanelProps: {
            type: import("vue").PropType<TdChatReasoningProps["collapsePanelProps"]>;
            default: () => TdChatReasoningProps["collapsePanelProps"];
        };
        expandIcon: {
            type: import("vue").PropType<TdChatReasoningProps["expandIcon"]>;
        };
        expandIconPlacement: {
            type: import("vue").PropType<TdChatReasoningProps["expandIconPlacement"]>;
            default: TdChatReasoningProps["expandIconPlacement"];
            validator(val: TdChatReasoningProps["expandIconPlacement"]): boolean;
        };
        header: {
            type: import("vue").PropType<TdChatReasoningProps["header"]>;
        };
        headerRightContent: {
            type: import("vue").PropType<TdChatReasoningProps["headerRightContent"]>;
        };
        onExpandChange: {
            type: import("vue").PropType<TdChatReasoningProps["onExpandChange"]>;
            default: () => void;
        };
        collapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        modelValue: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: TdChatReasoningProps["collapsed"];
        };
        defaultCollapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        layout: {
            type: import("vue").PropType<TdChatReasoningProps["layout"]>;
            default: string;
        };
    }>> & {
        "onUpdate:collapsed"?: (...args: any[]) => any;
    }, {
        layout: "block" | "border";
        modelValue: boolean;
        collapsed: boolean;
        onExpandChange: (value: boolean) => void;
        expandIconPlacement: "left" | "right";
        collapsePanelProps: import("@src/collapse").TdCollapsePanelProps;
        defaultCollapsed: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        collapsePanelProps: {
            type: import("vue").PropType<TdChatReasoningProps["collapsePanelProps"]>;
            default: () => TdChatReasoningProps["collapsePanelProps"];
        };
        expandIcon: {
            type: import("vue").PropType<TdChatReasoningProps["expandIcon"]>;
        };
        expandIconPlacement: {
            type: import("vue").PropType<TdChatReasoningProps["expandIconPlacement"]>;
            default: TdChatReasoningProps["expandIconPlacement"];
            validator(val: TdChatReasoningProps["expandIconPlacement"]): boolean;
        };
        header: {
            type: import("vue").PropType<TdChatReasoningProps["header"]>;
        };
        headerRightContent: {
            type: import("vue").PropType<TdChatReasoningProps["headerRightContent"]>;
        };
        onExpandChange: {
            type: import("vue").PropType<TdChatReasoningProps["onExpandChange"]>;
            default: () => void;
        };
        collapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        modelValue: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: TdChatReasoningProps["collapsed"];
        };
        defaultCollapsed: {
            type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
            default: boolean;
        };
        layout: {
            type: import("vue").PropType<TdChatReasoningProps["layout"]>;
            default: string;
        };
    }>> & {
        "onUpdate:collapsed"?: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        layout: "block" | "border";
        modelValue: boolean;
        collapsed: boolean;
        onExpandChange: (value: boolean) => void;
        expandIconPlacement: "left" | "right";
        collapsePanelProps: import("@src/collapse").TdCollapsePanelProps;
        defaultCollapsed: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    collapsePanelProps: {
        type: import("vue").PropType<TdChatReasoningProps["collapsePanelProps"]>;
        default: () => TdChatReasoningProps["collapsePanelProps"];
    };
    expandIcon: {
        type: import("vue").PropType<TdChatReasoningProps["expandIcon"]>;
    };
    expandIconPlacement: {
        type: import("vue").PropType<TdChatReasoningProps["expandIconPlacement"]>;
        default: TdChatReasoningProps["expandIconPlacement"];
        validator(val: TdChatReasoningProps["expandIconPlacement"]): boolean;
    };
    header: {
        type: import("vue").PropType<TdChatReasoningProps["header"]>;
    };
    headerRightContent: {
        type: import("vue").PropType<TdChatReasoningProps["headerRightContent"]>;
    };
    onExpandChange: {
        type: import("vue").PropType<TdChatReasoningProps["onExpandChange"]>;
        default: () => void;
    };
    collapsed: {
        type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
        default: TdChatReasoningProps["collapsed"];
    };
    defaultCollapsed: {
        type: import("vue").PropType<TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    layout: {
        type: import("vue").PropType<TdChatReasoningProps["layout"]>;
        default: string;
    };
}>> & {
    "onUpdate:collapsed"?: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "update:collapsed"[], "update:collapsed", {
    layout: "block" | "border";
    modelValue: boolean;
    collapsed: boolean;
    onExpandChange: (value: boolean) => void;
    expandIconPlacement: "left" | "right";
    collapsePanelProps: import("@src/collapse").TdCollapsePanelProps;
    defaultCollapsed: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export declare const ChatItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        reasoningLoading: {
            type: BooleanConstructor;
            default: boolean;
        };
        actions: {
            type: import("vue").PropType<TdChatItemProps["actions"]>;
        };
        animation: {
            type: import("vue").PropType<TdChatItemProps["animation"]>;
            default: TdChatItemProps["animation"];
            validator(val: TdChatItemProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatItemProps["avatar"]>;
        };
        content: {
            type: import("vue").PropType<TdChatItemProps["content"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatItemProps["datetime"]>;
        };
        name: {
            type: import("vue").PropType<TdChatItemProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatItemProps["reasoning"]>;
            default: TdChatItemProps["reasoning"];
        };
        role: {
            type: import("vue").PropType<TdChatItemProps["role"]>;
            validator(val: TdChatItemProps["role"]): boolean;
        };
        textLoading: BooleanConstructor;
        variant: {
            type: import("vue").PropType<TdChatItemProps["variant"]>;
            default: TdChatItemProps["variant"];
            validator(val: TdChatItemProps["variant"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatItemProps["status"]>;
            default: TdChatItemProps["status"];
        };
    }>> & {
        [x: `on${Capitalize<any>}`]: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any[], import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        reasoningLoading: {
            type: BooleanConstructor;
            default: boolean;
        };
        actions: {
            type: import("vue").PropType<TdChatItemProps["actions"]>;
        };
        animation: {
            type: import("vue").PropType<TdChatItemProps["animation"]>;
            default: TdChatItemProps["animation"];
            validator(val: TdChatItemProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatItemProps["avatar"]>;
        };
        content: {
            type: import("vue").PropType<TdChatItemProps["content"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatItemProps["datetime"]>;
        };
        name: {
            type: import("vue").PropType<TdChatItemProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatItemProps["reasoning"]>;
            default: TdChatItemProps["reasoning"];
        };
        role: {
            type: import("vue").PropType<TdChatItemProps["role"]>;
            validator(val: TdChatItemProps["role"]): boolean;
        };
        textLoading: BooleanConstructor;
        variant: {
            type: import("vue").PropType<TdChatItemProps["variant"]>;
            default: TdChatItemProps["variant"];
            validator(val: TdChatItemProps["variant"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatItemProps["status"]>;
            default: TdChatItemProps["status"];
        };
    }>> & {
        [x: `on${Capitalize<any>}`]: (...args: any[]) => any;
    }, {
        status: "" | "error";
        animation: "skeleton" | "gradient" | "moving";
        variant: "text" | "base" | "outline";
        reasoning: boolean | import("./type").TdChatReasoning;
        textLoading: boolean;
        reasoningLoading: boolean;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        reasoningLoading: {
            type: BooleanConstructor;
            default: boolean;
        };
        actions: {
            type: import("vue").PropType<TdChatItemProps["actions"]>;
        };
        animation: {
            type: import("vue").PropType<TdChatItemProps["animation"]>;
            default: TdChatItemProps["animation"];
            validator(val: TdChatItemProps["animation"]): boolean;
        };
        avatar: {
            type: import("vue").PropType<TdChatItemProps["avatar"]>;
        };
        content: {
            type: import("vue").PropType<TdChatItemProps["content"]>;
        };
        datetime: {
            type: import("vue").PropType<TdChatItemProps["datetime"]>;
        };
        name: {
            type: import("vue").PropType<TdChatItemProps["name"]>;
        };
        reasoning: {
            type: import("vue").PropType<TdChatItemProps["reasoning"]>;
            default: TdChatItemProps["reasoning"];
        };
        role: {
            type: import("vue").PropType<TdChatItemProps["role"]>;
            validator(val: TdChatItemProps["role"]): boolean;
        };
        textLoading: BooleanConstructor;
        variant: {
            type: import("vue").PropType<TdChatItemProps["variant"]>;
            default: TdChatItemProps["variant"];
            validator(val: TdChatItemProps["variant"]): boolean;
        };
        status: {
            type: import("vue").PropType<TdChatItemProps["status"]>;
            default: TdChatItemProps["status"];
        };
    }>> & {
        [x: `on${Capitalize<any>}`]: (...args: any[]) => any;
    }, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        status: "" | "error";
        animation: "skeleton" | "gradient" | "moving";
        variant: "text" | "base" | "outline";
        reasoning: boolean | import("./type").TdChatReasoning;
        textLoading: boolean;
        reasoningLoading: boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    reasoningLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    actions: {
        type: import("vue").PropType<TdChatItemProps["actions"]>;
    };
    animation: {
        type: import("vue").PropType<TdChatItemProps["animation"]>;
        default: TdChatItemProps["animation"];
        validator(val: TdChatItemProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<TdChatItemProps["avatar"]>;
    };
    content: {
        type: import("vue").PropType<TdChatItemProps["content"]>;
    };
    datetime: {
        type: import("vue").PropType<TdChatItemProps["datetime"]>;
    };
    name: {
        type: import("vue").PropType<TdChatItemProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<TdChatItemProps["reasoning"]>;
        default: TdChatItemProps["reasoning"];
    };
    role: {
        type: import("vue").PropType<TdChatItemProps["role"]>;
        validator(val: TdChatItemProps["role"]): boolean;
    };
    textLoading: BooleanConstructor;
    variant: {
        type: import("vue").PropType<TdChatItemProps["variant"]>;
        default: TdChatItemProps["variant"];
        validator(val: TdChatItemProps["variant"]): boolean;
    };
    status: {
        type: import("vue").PropType<TdChatItemProps["status"]>;
        default: TdChatItemProps["status"];
    };
}>> & {
    [x: `on${Capitalize<any>}`]: (...args: any[]) => any;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any[], any, {
    status: "" | "error";
    animation: "skeleton" | "gradient" | "moving";
    variant: "text" | "base" | "outline";
    reasoning: boolean | import("./type").TdChatReasoning;
    textLoading: boolean;
    reasoningLoading: boolean;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").Plugin;
export { TdMarkdownEngine as MarkdownEngine };
export { ToolCallRenderer };
declare const _default: {
    install(app: App, config?: Record<string, unknown>): void;
    version: string;
};
export default _default;
export { AGUIAdapter, getMessageContentForCopy, isAIMessage, isToolCallContent, } from 'tdesign-web-components/lib/chat-engine';
export type { SSEChunkData, AIMessageContent, ChatRequestParams, ChatMessagesData, ChatServiceConfig, } from 'tdesign-web-components/lib/chat-engine';

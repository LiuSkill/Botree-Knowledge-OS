declare const _default: import("vue").DefineComponent<{
    reasoningLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    actions: {
        type: import("vue").PropType<import("..").TdChatItemProps["actions"]>;
    };
    animation: {
        type: import("vue").PropType<import("..").TdChatItemProps["animation"]>;
        default: import("..").TdChatItemProps["animation"];
        validator(val: import("..").TdChatItemProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<import("..").TdChatItemProps["avatar"]>;
    };
    content: {
        type: import("vue").PropType<import("..").TdChatItemProps["content"]>;
    };
    datetime: {
        type: import("vue").PropType<import("..").TdChatItemProps["datetime"]>;
    };
    name: {
        type: import("vue").PropType<import("..").TdChatItemProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<import("..").TdChatItemProps["reasoning"]>;
        default: import("..").TdChatItemProps["reasoning"];
    };
    role: {
        type: import("vue").PropType<import("..").TdChatItemProps["role"]>;
        validator(val: import("..").TdChatItemProps["role"]): boolean;
    };
    textLoading: BooleanConstructor;
    variant: {
        type: import("vue").PropType<import("..").TdChatItemProps["variant"]>;
        default: import("..").TdChatItemProps["variant"];
        validator(val: import("..").TdChatItemProps["variant"]): boolean;
    };
    status: {
        type: import("vue").PropType<import("..").TdChatItemProps["status"]>;
        default: import("..").TdChatItemProps["status"];
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any[], any, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    reasoningLoading: {
        type: BooleanConstructor;
        default: boolean;
    };
    actions: {
        type: import("vue").PropType<import("..").TdChatItemProps["actions"]>;
    };
    animation: {
        type: import("vue").PropType<import("..").TdChatItemProps["animation"]>;
        default: import("..").TdChatItemProps["animation"];
        validator(val: import("..").TdChatItemProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<import("..").TdChatItemProps["avatar"]>;
    };
    content: {
        type: import("vue").PropType<import("..").TdChatItemProps["content"]>;
    };
    datetime: {
        type: import("vue").PropType<import("..").TdChatItemProps["datetime"]>;
    };
    name: {
        type: import("vue").PropType<import("..").TdChatItemProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<import("..").TdChatItemProps["reasoning"]>;
        default: import("..").TdChatItemProps["reasoning"];
    };
    role: {
        type: import("vue").PropType<import("..").TdChatItemProps["role"]>;
        validator(val: import("..").TdChatItemProps["role"]): boolean;
    };
    textLoading: BooleanConstructor;
    variant: {
        type: import("vue").PropType<import("..").TdChatItemProps["variant"]>;
        default: import("..").TdChatItemProps["variant"];
        validator(val: import("..").TdChatItemProps["variant"]): boolean;
    };
    status: {
        type: import("vue").PropType<import("..").TdChatItemProps["status"]>;
        default: import("..").TdChatItemProps["status"];
    };
}>> & {
    [x: `on${Capitalize<any>}`]: (...args: any[]) => any;
}, {
    status: "" | "error";
    animation: "skeleton" | "gradient" | "moving";
    variant: "text" | "base" | "outline";
    reasoning: boolean | import("..").TdChatReasoning;
    textLoading: boolean;
    reasoningLoading: boolean;
}, {}>;
export default _default;

import { TdChatItemProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    actions: {
        type: PropType<TdChatItemProps["actions"]>;
    };
    animation: {
        type: PropType<TdChatItemProps["animation"]>;
        default: TdChatItemProps["animation"];
        validator(val: TdChatItemProps["animation"]): boolean;
    };
    avatar: {
        type: PropType<TdChatItemProps["avatar"]>;
    };
    content: {
        type: PropType<TdChatItemProps["content"]>;
    };
    datetime: {
        type: PropType<TdChatItemProps["datetime"]>;
    };
    name: {
        type: PropType<TdChatItemProps["name"]>;
    };
    reasoning: {
        type: PropType<TdChatItemProps["reasoning"]>;
        default: TdChatItemProps["reasoning"];
    };
    role: {
        type: PropType<TdChatItemProps["role"]>;
        validator(val: TdChatItemProps["role"]): boolean;
    };
    textLoading: BooleanConstructor;
    variant: {
        type: PropType<TdChatItemProps["variant"]>;
        default: TdChatItemProps["variant"];
        validator(val: TdChatItemProps["variant"]): boolean;
    };
    status: {
        type: PropType<TdChatItemProps["status"]>;
        default: TdChatItemProps["status"];
    };
};
export default _default;

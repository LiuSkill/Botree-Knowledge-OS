declare const _default: import("vue").DefineComponent<{
    collapsePanelProps: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsePanelProps"]>;
        default: () => import("..").TdChatReasoningProps["collapsePanelProps"];
    };
    expandIcon: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["expandIcon"]>;
    };
    expandIconPlacement: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["expandIconPlacement"]>;
        default: import("..").TdChatReasoningProps["expandIconPlacement"];
        validator(val: import("..").TdChatReasoningProps["expandIconPlacement"]): boolean;
    };
    header: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["header"]>;
    };
    headerRightContent: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["headerRightContent"]>;
    };
    onExpandChange: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["onExpandChange"]>;
        default: () => void;
    };
    collapsed: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: import("..").TdChatReasoningProps["collapsed"];
    };
    defaultCollapsed: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    layout: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["layout"]>;
        default: string;
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "update:collapsed"[], "update:collapsed", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    collapsePanelProps: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsePanelProps"]>;
        default: () => import("..").TdChatReasoningProps["collapsePanelProps"];
    };
    expandIcon: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["expandIcon"]>;
    };
    expandIconPlacement: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["expandIconPlacement"]>;
        default: import("..").TdChatReasoningProps["expandIconPlacement"];
        validator(val: import("..").TdChatReasoningProps["expandIconPlacement"]): boolean;
    };
    header: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["header"]>;
    };
    headerRightContent: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["headerRightContent"]>;
    };
    onExpandChange: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["onExpandChange"]>;
        default: () => void;
    };
    collapsed: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    modelValue: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: import("..").TdChatReasoningProps["collapsed"];
    };
    defaultCollapsed: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    layout: {
        type: import("vue").PropType<import("..").TdChatReasoningProps["layout"]>;
        default: string;
    };
}>> & {
    "onUpdate:collapsed"?: (...args: any[]) => any;
}, {
    layout: "block" | "border";
    modelValue: boolean;
    collapsed: boolean;
    onExpandChange: (value: boolean) => void;
    expandIconPlacement: "left" | "right";
    collapsePanelProps: import("tdesign-vue-next").TdCollapsePanelProps;
    defaultCollapsed: boolean;
}, {}>;
export default _default;

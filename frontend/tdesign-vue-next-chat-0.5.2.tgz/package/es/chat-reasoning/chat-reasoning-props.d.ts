import { TdChatReasoningProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    collapsePanelProps: {
        type: PropType<TdChatReasoningProps["collapsePanelProps"]>;
        default: () => TdChatReasoningProps["collapsePanelProps"];
    };
    expandIcon: {
        type: PropType<TdChatReasoningProps["expandIcon"]>;
    };
    expandIconPlacement: {
        type: PropType<TdChatReasoningProps["expandIconPlacement"]>;
        default: TdChatReasoningProps["expandIconPlacement"];
        validator(val: TdChatReasoningProps["expandIconPlacement"]): boolean;
    };
    header: {
        type: PropType<TdChatReasoningProps["header"]>;
    };
    headerRightContent: {
        type: PropType<TdChatReasoningProps["headerRightContent"]>;
    };
    onExpandChange: {
        type: PropType<TdChatReasoningProps["onExpandChange"]>;
        default: () => void;
    };
    collapsed: {
        type: PropType<TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    modelValue: {
        type: PropType<TdChatReasoningProps["collapsed"]>;
        default: TdChatReasoningProps["collapsed"];
    };
    defaultCollapsed: {
        type: PropType<TdChatReasoningProps["collapsed"]>;
        default: boolean;
    };
    layout: {
        type: PropType<TdChatReasoningProps["layout"]>;
        default: string;
    };
};
export default _default;

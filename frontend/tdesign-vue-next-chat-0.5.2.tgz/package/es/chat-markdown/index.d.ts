import 'tdesign-web-components/lib/chat-message/content/markdown-content';
import type { DefineComponent } from 'vue';
import type { TdChatMarkdownContentProps } from 'tdesign-web-components/lib/chat-message/content/markdown-content';
export declare const ChatMarkdown: DefineComponent<TdChatMarkdownContentProps>;
export default ChatMarkdown;

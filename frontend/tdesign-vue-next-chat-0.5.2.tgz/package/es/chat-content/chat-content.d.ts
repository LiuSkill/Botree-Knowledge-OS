declare const _default: import("vue").DefineComponent<{
    content: {
        type: import("vue").PropType<import("..").TdChatContentProps["content"]>;
        default: string;
    };
    role: {
        type: import("vue").PropType<import("..").TdChatContentProps["role"]>;
        validator(val: import("..").TdChatContentProps["role"]): boolean;
    };
    status: {
        type: import("vue").PropType<import("..").TdChatContentProps["status"]>;
        default: string;
    };
    markdownProps: {
        type: import("vue").PropType<import("..").TdChatContentProps["markdownProps"]>;
        default: () => {
            engine: string;
            options: {};
        };
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    content: {
        type: import("vue").PropType<import("..").TdChatContentProps["content"]>;
        default: string;
    };
    role: {
        type: import("vue").PropType<import("..").TdChatContentProps["role"]>;
        validator(val: import("..").TdChatContentProps["role"]): boolean;
    };
    status: {
        type: import("vue").PropType<import("..").TdChatContentProps["status"]>;
        default: string;
    };
    markdownProps: {
        type: import("vue").PropType<import("..").TdChatContentProps["markdownProps"]>;
        default: () => {
            engine: string;
            options: {};
        };
    };
}>>, {
    status: "" | "error";
    content: string | import("..").ChatContentData;
    markdownProps: {
        engine: "marked" | "cherry-markdown";
        options: {
            [key: string]: any;
        };
    };
}, {}>;
export default _default;

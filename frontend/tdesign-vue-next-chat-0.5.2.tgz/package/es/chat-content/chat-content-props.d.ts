import { TdChatContentProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    content: {
        type: PropType<TdChatContentProps["content"]>;
        default: string;
    };
    role: {
        type: PropType<TdChatContentProps["role"]>;
        validator(val: TdChatContentProps["role"]): boolean;
    };
    status: {
        type: PropType<TdChatContentProps["status"]>;
        default: string;
    };
    markdownProps: {
        type: PropType<TdChatContentProps["markdownProps"]>;
        default: () => {
            engine: string;
            options: {};
        };
    };
};
export default _default;

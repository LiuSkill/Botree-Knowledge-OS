import { TdChatSenderProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    footerPrefix: {
        type: PropType<TdChatSenderProps["footerPrefix"]>;
    };
    stopDisabled: {
        type: PropType<TdChatSenderProps["stopDisabled"]>;
        default: boolean;
    };
    sendBtnDisabled: {
        type: PropType<TdChatSenderProps["sendBtnDisabled"]>;
        default: boolean;
    };
    loading: {
        type: PropType<TdChatSenderProps["loading"]>;
        default: boolean;
    };
    suffix: {
        type: PropType<TdChatSenderProps["suffix"]>;
    };
    textareaProps: {
        type: PropType<TdChatSenderProps["textareaProps"]>;
    };
    value: {
        type: PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    modelValue: {
        type: PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    defaultValue: {
        type: PropType<TdChatSenderProps["defaultValue"]>;
    };
    attachmentsProps: {
        type: PropType<TdChatSenderProps["attachmentsProps"]>;
    };
    onBlur: PropType<TdChatSenderProps["onBlur"]>;
    onChange: PropType<TdChatSenderProps["onChange"]>;
    onFocus: PropType<TdChatSenderProps["onFocus"]>;
    onSend: PropType<TdChatSenderProps["onSend"]>;
    onStop: PropType<TdChatSenderProps["onStop"]>;
};
export default _default;

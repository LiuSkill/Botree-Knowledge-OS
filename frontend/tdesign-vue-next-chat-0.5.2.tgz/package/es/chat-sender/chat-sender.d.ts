import type { TdChatSenderProps } from '../type';
declare const _default: import("vue").DefineComponent<{
    attachmentsProps: {
        type: ObjectConstructor;
        default: () => {
            items: any[];
            overflow: string;
        };
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    footerPrefix: {
        type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
    };
    stopDisabled: {
        type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
        default: boolean;
    };
    sendBtnDisabled: {
        type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
        default: boolean;
    };
    loading: {
        type: import("vue").PropType<TdChatSenderProps["loading"]>;
        default: boolean;
    };
    suffix: {
        type: import("vue").PropType<TdChatSenderProps["suffix"]>;
    };
    textareaProps: {
        type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
    };
    value: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
    onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
    onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
    onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
    onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "blur" | "stop" | "send" | "remove" | "update:modelValue" | "fileSelect" | "fileClick")[], "focus" | "blur" | "stop" | "send" | "remove" | "update:modelValue" | "fileSelect" | "fileClick", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    attachmentsProps: {
        type: ObjectConstructor;
        default: () => {
            items: any[];
            overflow: string;
        };
    };
    disabled: BooleanConstructor;
    placeholder: {
        type: StringConstructor;
        default: string;
    };
    footerPrefix: {
        type: import("vue").PropType<TdChatSenderProps["footerPrefix"]>;
    };
    stopDisabled: {
        type: import("vue").PropType<TdChatSenderProps["stopDisabled"]>;
        default: boolean;
    };
    sendBtnDisabled: {
        type: import("vue").PropType<TdChatSenderProps["sendBtnDisabled"]>;
        default: boolean;
    };
    loading: {
        type: import("vue").PropType<TdChatSenderProps["loading"]>;
        default: boolean;
    };
    suffix: {
        type: import("vue").PropType<TdChatSenderProps["suffix"]>;
    };
    textareaProps: {
        type: import("vue").PropType<TdChatSenderProps["textareaProps"]>;
    };
    value: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    modelValue: {
        type: import("vue").PropType<TdChatSenderProps["value"]>;
        default: TdChatSenderProps["value"];
    };
    defaultValue: {
        type: import("vue").PropType<TdChatSenderProps["defaultValue"]>;
    };
    onBlur: import("vue").PropType<TdChatSenderProps["onBlur"]>;
    onChange: import("vue").PropType<TdChatSenderProps["onChange"]>;
    onFocus: import("vue").PropType<TdChatSenderProps["onFocus"]>;
    onSend: import("vue").PropType<TdChatSenderProps["onSend"]>;
    onStop: import("vue").PropType<TdChatSenderProps["onStop"]>;
}>> & {
    onFocus?: (...args: any[]) => any;
    onBlur?: (...args: any[]) => any;
    onRemove?: (...args: any[]) => any;
    onSend?: (...args: any[]) => any;
    onStop?: (...args: any[]) => any;
    "onUpdate:modelValue"?: (...args: any[]) => any;
    onFileClick?: (...args: any[]) => any;
    onFileSelect?: (...args: any[]) => any;
}, {
    disabled: boolean;
    value: string;
    loading: boolean;
    placeholder: string;
    modelValue: string;
    stopDisabled: boolean;
    sendBtnDisabled: boolean;
    attachmentsProps: Record<string, any>;
}, {}>;
export default _default;

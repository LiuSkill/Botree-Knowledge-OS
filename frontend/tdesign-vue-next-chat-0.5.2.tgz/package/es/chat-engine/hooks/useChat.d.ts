import { type Ref } from 'vue';
import type { ChatMessagesData, ChatStatus, ChatServiceConfig } from 'tdesign-web-components/lib/chat-engine';
import { TdChatProps } from 'tdesign-web-components';
export declare const useChat: (options: {
    defaultMessages: TdChatProps["defaultMessages"];
    chatServiceConfig: ChatServiceConfig;
}) => {
    chatEngine: Ref<{
        messageStore: {
            initialize: (initialState?: Partial<import("tdesign-web-components").ChatMessageStore>) => void;
            createMessage: (message: ChatMessagesData) => void;
            createMultiMessages: (messages: ChatMessagesData[]) => void;
            setMessages: (messages: ChatMessagesData[], mode?: import("tdesign-web-components").ChatMessageSetterMode) => void;
            appendContent: (messageId: string, processedContent: import("tdesign-web-components").AIMessageContent, targetIndex?: number) => void;
            replaceContent: (messageId: string, processedContent: import("tdesign-web-components").AIMessageContent[]) => void;
            setMessageStatus: (messageId: string, status: ChatMessagesData["status"]) => void;
            setMessageExt: (messageId: string, attr?: {}) => void;
            clearHistory: () => void;
            removeMessage: (messageId: string) => void;
            createMessageBranch: (messageId: string) => void;
            readonly messages: ChatMessagesData[];
            getMessageByID: (id: string) => ChatMessagesData;
            readonly currentMessage: ChatMessagesData;
            readonly lastAIMessage: import("tdesign-web-components").AIMessage | undefined;
            readonly lastUserMessage: import("tdesign-web-components").UserMessage | undefined;
            updateMultipleContents: (messageId: string, contents: import("tdesign-web-components").AIMessageContent[]) => void;
            setState: (updater: (draft: import("tdesign-web-components").ChatMessageStore) => void, paths?: string[]) => void;
            getState: (cloned?: boolean) => Readonly<import("tdesign-web-components").ChatMessageStore>;
            subscribe: (subscriber: import("tdesign-web-components/lib/chat-engine/store/reactiveState").Subscriber<import("tdesign-web-components").ChatMessageStore>, paths?: string[]) => () => void;
            destroy: () => void;
            debug: (label?: string) => import("tdesign-web-components/lib/chat-engine/store/message").MessageStore;
        };
        readonly eventBus: {
            on: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, callback: import("tdesign-web-components").EventCallback<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>) => import("tdesign-web-components").UnsubscribeFn;
            once: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, callback: import("tdesign-web-components").EventCallback<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>) => import("tdesign-web-components").UnsubscribeFn;
            off: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, callback?: import("tdesign-web-components").EventCallback<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>) => void;
            emit: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, payload: import("tdesign-web-components").ChatEngineEventPayloadMap[E]) => void;
            waitFor: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, timeout?: number) => Promise<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>;
            waitForMatch: <E extends import("tdesign-web-components").ChatEngineEventType>(event: E, filter: import("tdesign-web-components").EventFilter<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>, timeout?: number) => Promise<import("tdesign-web-components").ChatEngineEventPayloadMap[E]>;
            onCustom: <T = unknown>(eventName: string, callback: import("tdesign-web-components").EventCallback<T>) => import("tdesign-web-components").UnsubscribeFn;
            emitCustom: <T = unknown>(eventName: string, data: T) => void;
            getHistory: () => import("tdesign-web-components").EventHistoryItem[];
            clear: () => void;
            destroy: () => void;
        };
        readonly messages: ChatMessagesData[];
        readonly status: ChatStatus;
        destroy: () => void;
        init: (configSetter: import("tdesign-web-components").ChatServiceConfigSetter, initialMessages?: ChatMessagesData[]) => void;
        sendUserMessage: (requestParams: import("tdesign-web-components").ChatRequestParams, sendRequest?: boolean) => Promise<void>;
        sendSystemMessage: (msg: string) => Promise<void>;
        sendAIMessage: (options?: {
            params?: import("tdesign-web-components").ChatRequestParams;
            content?: import("tdesign-web-components").AIMessageContent[];
            sendRequest?: boolean;
        }) => Promise<void>;
        abortChat: () => Promise<void>;
        registerMergeStrategy: <T extends import("tdesign-web-components").AIMessageContent>(type: T["type"], handler: (chunk: T, existing?: T) => T) => void;
        setMessages: (messages: ChatMessagesData[], mode?: import("tdesign-web-components").ChatMessageSetterMode) => void;
        clearMessages: () => void;
        regenerateAIMessage: (keepVersion?: boolean) => Promise<void>;
        sendRequest: (params: import("tdesign-web-components").ChatRequestParams) => Promise<void>;
        getToolcallByName: (name: string) => import("tdesign-web-components").ToolCall | undefined;
    }>;
    messages: Ref<ChatMessagesData[]>;
    status: Ref<ChatStatus>;
};

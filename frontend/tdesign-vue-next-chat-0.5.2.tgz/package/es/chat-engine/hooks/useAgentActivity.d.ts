import type { ActivityConfig } from '../components/activity/types';
export interface UseAgentActivityReturn {
    register: (config: ActivityConfig | ActivityConfig[]) => void;
    unregister: (activityTypes: string | string[]) => void;
    isRegistered: (activityType: string) => boolean;
    getRegistered: () => string[];
}
export declare function useAgentActivity<TContent = any>(config?: ActivityConfig<TContent> | ActivityConfig<TContent>[] | null | undefined): UseAgentActivityReturn;

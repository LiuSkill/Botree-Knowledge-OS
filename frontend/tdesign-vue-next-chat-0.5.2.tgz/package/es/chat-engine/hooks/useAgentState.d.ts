import { type Ref, type InjectionKey } from 'vue';
export interface StateActionOptions {
    initialState?: Record<string, any>;
    subscribeKey?: string;
}
export interface UseStateActionReturn {
    stateMap: Ref<Record<string, any>>;
    currentStateKey: Ref<string | null>;
    setStateMap: (stateMap: Record<string, any> | ((prev: Record<string, any>) => Record<string, any>)) => void;
    getCurrentState: () => Record<string, any>;
    getStateByKey: (key: string) => any;
}
export declare const useAgentState: <T = any>(options?: StateActionOptions) => UseStateActionReturn;
export declare const AgentStateKey: InjectionKey<UseStateActionReturn>;
export declare const provideAgentState: (state: UseStateActionReturn) => void;
export declare const useAgentStateDataByKey: (stateKey?: Ref<string | undefined> | string) => import("vue").ComputedRef<any>;
export declare const useAgentStateContext: () => UseStateActionReturn;

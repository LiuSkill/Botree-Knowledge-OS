import { type Ref } from 'vue';
import type { AgentToolcallConfig, ToolcallComponentProps } from '../components/toolcall/types';
export interface UseAgentToolcallReturn {
    register: (config: AgentToolcallConfig | AgentToolcallConfig[]) => void;
    unregister: (names: string | string[]) => void;
    isRegistered: (name: string) => boolean;
    getRegistered: () => string[];
    config: Ref<any>;
}
export declare function useAgentToolcall<TArgs extends object = any, TResult = any, TResponse = any>(config?: AgentToolcallConfig<TArgs, TResult, TResponse> | AgentToolcallConfig<TArgs, TResult, TResponse>[] | null | undefined): UseAgentToolcallReturn;
export interface ToolConfigWithStateOptions<TArgs extends object = any, TResult = any> {
    name: string;
    description: string;
    parameters: Array<{
        name: string;
        type: string;
    }>;
    subscribeKey?: (props: ToolcallComponentProps<TArgs, TResult>) => string | undefined;
    component: new (props: ToolcallComponentProps<TArgs, TResult> & {
        agentState?: Record<string, any>;
    }) => any;
}

export interface ActivityComponentProps<TContent = any> {
    activityType: string;
    content: TContent;
    messageId: string;
}
export interface ActivityConfig<TContent = any> {
    activityType: string;
    component: (props: ActivityComponentProps<TContent>) => any;
    description?: string;
}
export interface ActivityRegistry {
    [activityType: string]: ActivityConfig;
}

import type { ActivityConfig } from './types';
export declare const ACTIVITY_REGISTERED_EVENT = "activity-registered";
export declare const ACTIVITY_EVENT_DETAIL_KEY = "activityType";
export declare const activityRegistry: import("../shared").IRegistryManager<ActivityConfig<any>>;

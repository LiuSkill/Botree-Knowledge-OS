import type { ActivityData } from 'tdesign-web-components';
declare const _default: import("vue").DefineComponent<{
    activity: {
        type: () => ActivityData;
        required: true;
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    activity: {
        type: () => ActivityData;
        required: true;
    };
}>>, {}, {}>;
export default _default;

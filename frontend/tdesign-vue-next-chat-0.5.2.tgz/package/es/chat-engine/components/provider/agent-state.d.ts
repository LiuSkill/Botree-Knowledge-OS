declare const _default: import("vue").DefineComponent<{
    initialState: {
        type: ObjectConstructor;
        default: () => {};
    };
    subscribeKey: {
        type: StringConstructor;
        default: any;
    };
}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[], unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    initialState: {
        type: ObjectConstructor;
        default: () => {};
    };
    subscribeKey: {
        type: StringConstructor;
        default: any;
    };
}>>, {
    initialState: Record<string, any>;
    subscribeKey: string;
}, {}>;
export default _default;

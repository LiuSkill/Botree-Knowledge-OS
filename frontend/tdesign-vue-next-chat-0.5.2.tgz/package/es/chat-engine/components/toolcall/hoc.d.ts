import { type DefineComponent } from 'vue';
export type WithAgentStateProps<P extends object = any> = P & {
    agentState?: Record<string, any>;
};
export declare const withAgentStateToolcall1: <P extends object = any>(Component: DefineComponent<WithAgentStateProps<P>>) => DefineComponent<P>;
export declare const withAgentStateToolcall: <P extends object = any>(Component: DefineComponent<WithAgentStateProps<P>>, subscribeKeyExtractor?: (props: P) => string | undefined) => DefineComponent<P>;

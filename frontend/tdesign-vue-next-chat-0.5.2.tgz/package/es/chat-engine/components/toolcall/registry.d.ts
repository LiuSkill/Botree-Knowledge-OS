import type { AgentToolcallConfig } from './types';
export declare const TOOLCALL_REGISTERED_EVENT = "toolcall-registered";
export declare const TOOLCALL_EVENT_DETAIL_KEY = "name";
export declare const agentToolcallRegistry: import("../shared").IRegistryManager<AgentToolcallConfig>;

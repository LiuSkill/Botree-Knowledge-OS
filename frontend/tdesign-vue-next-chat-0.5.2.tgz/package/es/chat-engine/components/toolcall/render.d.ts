import { type ToolCall } from 'tdesign-web-components/lib/chat-engine';
declare const _default: import("vue").DefineComponent<{
    toolCall: {
        type: () => ToolCall;
        required: true;
    };
    onRespond: {
        type: () => (toolCall: ToolCall, response: any) => void;
        default: any;
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    toolCall: {
        type: () => ToolCall;
        required: true;
    };
    onRespond: {
        type: () => (toolCall: ToolCall, response: any) => void;
        default: any;
    };
}>>, {
    onRespond: (toolCall: ToolCall, response: any) => void;
}, {}>;
export default _default;

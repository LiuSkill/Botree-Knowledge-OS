import { type Component, type Ref, type ComputedRef } from 'vue';
interface UseRegistrationListenerOptions {
    componentKey: string | Ref<string> | ComputedRef<string>;
    eventName: string;
    eventDetailKey: string;
    getRenderFunction: (key: string) => Component | null;
}
interface UseRegistrationListenerResult {
    isRegistered: Ref<boolean>;
    MemoizedComponent: Ref<Component | null>;
}
export declare function useRegistrationListener(options: UseRegistrationListenerOptions): UseRegistrationListenerResult;
export {};

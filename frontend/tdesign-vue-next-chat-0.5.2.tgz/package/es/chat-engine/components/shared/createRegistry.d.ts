import type { Component } from 'vue';
export interface BaseConfig {
    component: Component;
}
export interface RegistryOptions<TConfig extends BaseConfig> {
    getKey: (config: TConfig) => string;
    eventName: string;
    eventDetailKey: string;
}
export interface IRegistryManager<TConfig extends BaseConfig> {
    register(config: TConfig): boolean;
    get(key: string): TConfig | undefined;
    getRenderFunction(key: string): Component | null;
    getAll(): Record<string, TConfig>;
    unregister(key: string): void;
    clear(): void;
    has(key: string): boolean;
    getRegisteredKeys(): string[];
}
export declare function createRegistryManager<TConfig extends BaseConfig>(options: RegistryOptions<TConfig>): IRegistryManager<TConfig>;

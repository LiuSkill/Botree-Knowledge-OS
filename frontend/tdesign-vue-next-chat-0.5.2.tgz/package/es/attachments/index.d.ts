import 'tdesign-web-components/lib/attachments';
import type { TdAttachmentsProps } from 'tdesign-web-components';
import type { DefineComponent } from 'vue';
export declare const Attachments: DefineComponent<TdAttachmentsProps>;
export default Attachments;

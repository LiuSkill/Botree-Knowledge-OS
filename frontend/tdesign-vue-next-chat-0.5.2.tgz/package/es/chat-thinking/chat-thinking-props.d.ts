import type { TdChatThinkContentProps } from 'tdesign-web-components/lib/chat-message/content/thinking-content';
import { PropType } from 'vue';
import type { TNode } from 'tdesign-vue-next';
declare const _default: {
    layout: {
        type: PropType<TdChatThinkContentProps["layout"]>;
        default: TdChatThinkContentProps["layout"];
        validator(val: TdChatThinkContentProps["layout"]): boolean;
    };
    status: {
        type: PropType<TdChatThinkContentProps["status"]>;
        default: TdChatThinkContentProps["status"];
        validator(val: TdChatThinkContentProps["status"]): boolean;
    };
    maxHeight: {
        type: PropType<TdChatThinkContentProps["maxHeight"]>;
    };
    animation: {
        type: PropType<TdChatThinkContentProps["animation"]>;
        default: TdChatThinkContentProps["animation"];
        validator(val: TdChatThinkContentProps["animation"]): boolean;
    };
    content: {
        type: PropType<TNode>;
    };
    collapsed: {
        type: PropType<TdChatThinkContentProps["collapsed"]>;
        default: TdChatThinkContentProps["collapsed"];
    };
};
export default _default;

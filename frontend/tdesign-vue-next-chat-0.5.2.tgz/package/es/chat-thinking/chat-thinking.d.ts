import type { DefineComponent } from 'vue';
import type { TdChatThinkContentProps } from 'tdesign-web-components/lib/chat-message/content/thinking-content';
import 'tdesign-web-components/lib/chat-message/content/thinking-content';
declare const _default: DefineComponent<{
    layout: {
        type: import("vue").PropType<TdChatThinkContentProps["layout"]>;
        default: TdChatThinkContentProps["layout"];
        validator(val: TdChatThinkContentProps["layout"]): boolean;
    };
    status: {
        type: import("vue").PropType<TdChatThinkContentProps["status"]>;
        default: TdChatThinkContentProps["status"];
        validator(val: TdChatThinkContentProps["status"]): boolean;
    };
    maxHeight: {
        type: import("vue").PropType<TdChatThinkContentProps["maxHeight"]>;
    };
    animation: {
        type: import("vue").PropType<TdChatThinkContentProps["animation"]>;
        default: TdChatThinkContentProps["animation"];
        validator(val: TdChatThinkContentProps["animation"]): boolean;
    };
    content: {
        type: import("vue").PropType<import("@src/common").TNode>;
    };
    collapsed: {
        type: import("vue").PropType<TdChatThinkContentProps["collapsed"]>;
        default: TdChatThinkContentProps["collapsed"];
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    layout: {
        type: import("vue").PropType<TdChatThinkContentProps["layout"]>;
        default: TdChatThinkContentProps["layout"];
        validator(val: TdChatThinkContentProps["layout"]): boolean;
    };
    status: {
        type: import("vue").PropType<TdChatThinkContentProps["status"]>;
        default: TdChatThinkContentProps["status"];
        validator(val: TdChatThinkContentProps["status"]): boolean;
    };
    maxHeight: {
        type: import("vue").PropType<TdChatThinkContentProps["maxHeight"]>;
    };
    animation: {
        type: import("vue").PropType<TdChatThinkContentProps["animation"]>;
        default: TdChatThinkContentProps["animation"];
        validator(val: TdChatThinkContentProps["animation"]): boolean;
    };
    content: {
        type: import("vue").PropType<import("@src/common").TNode>;
    };
    collapsed: {
        type: import("vue").PropType<TdChatThinkContentProps["collapsed"]>;
        default: TdChatThinkContentProps["collapsed"];
    };
}>>, {
    layout: "block" | "border";
    status: import("tdesign-web-components").ChatMessageStatus;
    animation: import("tdesign-web-components").ChatLoadingAnimationType;
    collapsed: boolean;
}, {}>;
export default _default;

import { TdChatActionProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    content: {
        type: StringConstructor;
        default: string;
    };
    disabled: BooleanConstructor;
    comment: {
        type: PropType<"good" | "bad" | "">;
        validator: (value: string) => boolean;
        default: string;
    };
    isBad: {
        type: BooleanConstructor;
        default: boolean;
    };
    isGood: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionBar: {
        type: PropType<TdChatActionProps["actionBar"]>;
        default: () => TdChatActionProps["actionBar"];
    };
    operationBtn: {
        type: PropType<TdChatActionProps["operationBtn"]>;
        default: () => TdChatActionProps["operationBtn"];
    };
    onActions: PropType<TdChatActionProps["onActions"]>;
    onOperation: PropType<TdChatActionProps["onOperation"]>;
};
export default _default;

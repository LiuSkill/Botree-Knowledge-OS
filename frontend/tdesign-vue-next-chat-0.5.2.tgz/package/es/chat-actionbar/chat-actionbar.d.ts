declare const _default: import("vue").DefineComponent<{
    content: {
        type: StringConstructor;
        default: string;
    };
    disabled: BooleanConstructor;
    comment: {
        type: import("vue").PropType<"good" | "bad" | "">;
        validator: (value: string) => boolean;
        default: string;
    };
    isBad: {
        type: BooleanConstructor;
        default: boolean;
    };
    isGood: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionBar: {
        type: import("vue").PropType<import("..").TdChatActionProps["actionBar"]>;
        default: () => import("..").TdChatActionProps["actionBar"];
    };
    operationBtn: {
        type: import("vue").PropType<import("..").TdChatActionProps["operationBtn"]>;
        default: () => import("..").TdChatActionProps["operationBtn"];
    };
    onActions: import("vue").PropType<import("..").TdChatActionProps["onActions"]>;
    onOperation: import("vue").PropType<import("..").TdChatActionProps["onOperation"]>;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("operation" | "actions")[], "operation" | "actions", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    content: {
        type: StringConstructor;
        default: string;
    };
    disabled: BooleanConstructor;
    comment: {
        type: import("vue").PropType<"good" | "bad" | "">;
        validator: (value: string) => boolean;
        default: string;
    };
    isBad: {
        type: BooleanConstructor;
        default: boolean;
    };
    isGood: {
        type: BooleanConstructor;
        default: boolean;
    };
    actionBar: {
        type: import("vue").PropType<import("..").TdChatActionProps["actionBar"]>;
        default: () => import("..").TdChatActionProps["actionBar"];
    };
    operationBtn: {
        type: import("vue").PropType<import("..").TdChatActionProps["operationBtn"]>;
        default: () => import("..").TdChatActionProps["operationBtn"];
    };
    onActions: import("vue").PropType<import("..").TdChatActionProps["onActions"]>;
    onOperation: import("vue").PropType<import("..").TdChatActionProps["onOperation"]>;
}>> & {
    onActions?: (...args: any[]) => any;
    onOperation?: (...args: any[]) => any;
}, {
    disabled: boolean;
    comment: "" | "good" | "bad";
    content: string;
    actionBar: ("copy" | "share" | "good" | "bad" | "replay")[];
    operationBtn: ("copy" | "share" | "good" | "bad" | "replay")[];
    isBad: boolean;
    isGood: boolean;
}, {}>;
export default _default;

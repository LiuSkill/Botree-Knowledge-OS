declare const _default: import("vue").DefineComponent<{
    actions: {
        type: import("vue").PropType<import("..").TdChatProps["actions"]>;
    };
    actionbar: {
        type: import("vue").PropType<import("..").TdChatProps["actionbar"]>;
    };
    autoScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    defaultScrollTo: {
        type: import("vue").PropType<import("..").TdChatProps["defaultScrollTo"]>;
        default: import("..").TdChatProps["defaultScrollTo"];
        validator(val: import("..").TdChatProps["defaultScrollTo"]): boolean;
    };
    animation: {
        type: import("vue").PropType<import("..").TdChatProps["animation"]>;
        default: import("..").TdChatProps["animation"];
        validator(val: import("..").TdChatProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<import("..").TdChatProps["avatar"]>;
    };
    clearHistory: {
        type: BooleanConstructor;
        default: boolean;
    };
    content: {
        type: import("vue").PropType<import("..").TdChatProps["content"]>;
    };
    data: {
        type: import("vue").PropType<import("..").TdChatProps["data"]>;
    };
    datetime: {
        type: import("vue").PropType<import("..").TdChatProps["datetime"]>;
    };
    isStreamLoad: BooleanConstructor;
    layout: {
        type: import("vue").PropType<import("..").TdChatProps["layout"]>;
        default: import("..").TdChatProps["layout"];
        validator(val: import("..").TdChatProps["layout"]): boolean;
    };
    name: {
        type: import("vue").PropType<import("..").TdChatProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<import("..").TdChatProps["reasoning"]>;
    };
    reverse: {
        type: BooleanConstructor;
        default: boolean;
    };
    showScrollButton: {
        type: import("vue").PropType<import("..").TdChatProps["showScrollButton"]>;
        default: boolean;
    };
    textLoading: BooleanConstructor;
    onClear: import("vue").PropType<import("..").TdChatProps["onClear"]>;
    onScroll: import("vue").PropType<import("..").TdChatProps["onScroll"]>;
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("scroll" | "clear")[], "scroll" | "clear", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    actions: {
        type: import("vue").PropType<import("..").TdChatProps["actions"]>;
    };
    actionbar: {
        type: import("vue").PropType<import("..").TdChatProps["actionbar"]>;
    };
    autoScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    defaultScrollTo: {
        type: import("vue").PropType<import("..").TdChatProps["defaultScrollTo"]>;
        default: import("..").TdChatProps["defaultScrollTo"];
        validator(val: import("..").TdChatProps["defaultScrollTo"]): boolean;
    };
    animation: {
        type: import("vue").PropType<import("..").TdChatProps["animation"]>;
        default: import("..").TdChatProps["animation"];
        validator(val: import("..").TdChatProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<import("..").TdChatProps["avatar"]>;
    };
    clearHistory: {
        type: BooleanConstructor;
        default: boolean;
    };
    content: {
        type: import("vue").PropType<import("..").TdChatProps["content"]>;
    };
    data: {
        type: import("vue").PropType<import("..").TdChatProps["data"]>;
    };
    datetime: {
        type: import("vue").PropType<import("..").TdChatProps["datetime"]>;
    };
    isStreamLoad: BooleanConstructor;
    layout: {
        type: import("vue").PropType<import("..").TdChatProps["layout"]>;
        default: import("..").TdChatProps["layout"];
        validator(val: import("..").TdChatProps["layout"]): boolean;
    };
    name: {
        type: import("vue").PropType<import("..").TdChatProps["name"]>;
    };
    reasoning: {
        type: import("vue").PropType<import("..").TdChatProps["reasoning"]>;
    };
    reverse: {
        type: BooleanConstructor;
        default: boolean;
    };
    showScrollButton: {
        type: import("vue").PropType<import("..").TdChatProps["showScrollButton"]>;
        default: boolean;
    };
    textLoading: BooleanConstructor;
    onClear: import("vue").PropType<import("..").TdChatProps["onClear"]>;
    onScroll: import("vue").PropType<import("..").TdChatProps["onScroll"]>;
}>> & {
    onScroll?: (...args: any[]) => any;
    onClear?: (...args: any[]) => any;
}, {
    reverse: boolean;
    layout: "single" | "both";
    animation: "skeleton" | "gradient" | "moving";
    defaultScrollTo: "top" | "bottom";
    showScrollButton: boolean;
    autoScroll: boolean;
    clearHistory: boolean;
    isStreamLoad: boolean;
    textLoading: boolean;
}, {}>;
export default _default;

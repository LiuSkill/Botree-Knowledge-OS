export declare class MockSSEResponse {
    private data;
    private delay;
    private controller;
    private encoder;
    private stream;
    private error;
    private currentPhase;
    constructor(data: {
        reasoning: string;
        content: string;
    }, delay?: number, error?: boolean);
    private pushData;
    getResponse(): Promise<Response>;
}

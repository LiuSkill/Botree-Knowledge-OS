import { TdChatProps } from '../type';
import { PropType } from 'vue';
declare const _default: {
    actions: {
        type: PropType<TdChatProps["actions"]>;
    };
    actionbar: {
        type: PropType<TdChatProps["actionbar"]>;
    };
    autoScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    defaultScrollTo: {
        type: PropType<TdChatProps["defaultScrollTo"]>;
        default: TdChatProps["defaultScrollTo"];
        validator(val: TdChatProps["defaultScrollTo"]): boolean;
    };
    animation: {
        type: PropType<TdChatProps["animation"]>;
        default: TdChatProps["animation"];
        validator(val: TdChatProps["animation"]): boolean;
    };
    avatar: {
        type: PropType<TdChatProps["avatar"]>;
    };
    clearHistory: {
        type: BooleanConstructor;
        default: boolean;
    };
    content: {
        type: PropType<TdChatProps["content"]>;
    };
    data: {
        type: PropType<TdChatProps["data"]>;
    };
    datetime: {
        type: PropType<TdChatProps["datetime"]>;
    };
    isStreamLoad: BooleanConstructor;
    layout: {
        type: PropType<TdChatProps["layout"]>;
        default: TdChatProps["layout"];
        validator(val: TdChatProps["layout"]): boolean;
    };
    name: {
        type: PropType<TdChatProps["name"]>;
    };
    reasoning: {
        type: PropType<TdChatProps["reasoning"]>;
    };
    reverse: {
        type: BooleanConstructor;
        default: boolean;
    };
    showScrollButton: {
        type: PropType<TdChatProps["showScrollButton"]>;
        default: boolean;
    };
    textLoading: BooleanConstructor;
    onClear: PropType<TdChatProps["onClear"]>;
    onScroll: PropType<TdChatProps["onScroll"]>;
};
export default _default;

export declare class MessagePluginSingleton {
    private static instance;
    private messagePlugin;
    private constructor();
    static getInstance(): MessagePluginSingleton;
    showSuccess(copyTextSuccess: string): void;
    showError(copyTextFail: string): void;
}

import type { DefineComponent } from 'vue';
import type { TdChatMessageProps } from 'tdesign-web-components';
import 'tdesign-web-components/lib/chat-message';
declare const _default: DefineComponent<{
    animation: {
        type: import("vue").PropType<TdChatMessageProps["animation"]>;
        default: TdChatMessageProps["animation"];
        validator(val: TdChatMessageProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<TdChatMessageProps["avatar"]>;
    };
    datetime: {
        type: import("vue").PropType<TdChatMessageProps["datetime"]>;
    };
    role: {
        type: import("vue").PropType<TdChatMessageProps["role"]>;
    };
    status: {
        type: import("vue").PropType<TdChatMessageProps["status"]>;
    };
    content: {
        type: import("vue").PropType<TdChatMessageProps["content"]>;
    };
    name: {
        type: import("vue").PropType<TdChatMessageProps["name"]>;
    };
    variant: {
        type: import("vue").PropType<TdChatMessageProps["variant"]>;
        default: TdChatMessageProps["variant"];
        validator(val: TdChatMessageProps["variant"]): boolean;
    };
    message: {
        type: import("vue").PropType<TdChatMessageProps["message"]>;
    };
    placement: {
        type: import("vue").PropType<TdChatMessageProps["placement"]>;
        default: TdChatMessageProps["placement"];
    };
    chatContentProps: {
        type: import("vue").PropType<TdChatMessageProps["chatContentProps"]>;
    };
    allowContentSegmentCustom: {
        type: BooleanConstructor;
        default: boolean;
    };
}, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    animation: {
        type: import("vue").PropType<TdChatMessageProps["animation"]>;
        default: TdChatMessageProps["animation"];
        validator(val: TdChatMessageProps["animation"]): boolean;
    };
    avatar: {
        type: import("vue").PropType<TdChatMessageProps["avatar"]>;
    };
    datetime: {
        type: import("vue").PropType<TdChatMessageProps["datetime"]>;
    };
    role: {
        type: import("vue").PropType<TdChatMessageProps["role"]>;
    };
    status: {
        type: import("vue").PropType<TdChatMessageProps["status"]>;
    };
    content: {
        type: import("vue").PropType<TdChatMessageProps["content"]>;
    };
    name: {
        type: import("vue").PropType<TdChatMessageProps["name"]>;
    };
    variant: {
        type: import("vue").PropType<TdChatMessageProps["variant"]>;
        default: TdChatMessageProps["variant"];
        validator(val: TdChatMessageProps["variant"]): boolean;
    };
    message: {
        type: import("vue").PropType<TdChatMessageProps["message"]>;
    };
    placement: {
        type: import("vue").PropType<TdChatMessageProps["placement"]>;
        default: TdChatMessageProps["placement"];
    };
    chatContentProps: {
        type: import("vue").PropType<TdChatMessageProps["chatContentProps"]>;
    };
    allowContentSegmentCustom: {
        type: BooleanConstructor;
        default: boolean;
    };
}>>, {
    animation: import("tdesign-web-components").ChatLoadingAnimationType;
    variant: import("tdesign-web-components").TdChatMessageVariant;
    placement: "left" | "right";
    allowContentSegmentCustom: boolean;
}, {}>;
export default _default;

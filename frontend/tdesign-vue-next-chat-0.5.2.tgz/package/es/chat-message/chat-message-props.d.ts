import type { TdChatMessageProps } from 'tdesign-web-components';
import { PropType } from 'vue';
declare const _default: {
    animation: {
        type: PropType<TdChatMessageProps["animation"]>;
        default: TdChatMessageProps["animation"];
        validator(val: TdChatMessageProps["animation"]): boolean;
    };
    avatar: {
        type: PropType<TdChatMessageProps["avatar"]>;
    };
    datetime: {
        type: PropType<TdChatMessageProps["datetime"]>;
    };
    role: {
        type: PropType<TdChatMessageProps["role"]>;
    };
    status: {
        type: PropType<TdChatMessageProps["status"]>;
    };
    content: {
        type: PropType<TdChatMessageProps["content"]>;
    };
    name: {
        type: PropType<TdChatMessageProps["name"]>;
    };
    variant: {
        type: PropType<TdChatMessageProps["variant"]>;
        default: TdChatMessageProps["variant"];
        validator(val: TdChatMessageProps["variant"]): boolean;
    };
    message: {
        type: PropType<TdChatMessageProps["message"]>;
    };
    placement: {
        type: PropType<TdChatMessageProps["placement"]>;
        default: TdChatMessageProps["placement"];
    };
    chatContentProps: {
        type: PropType<TdChatMessageProps["chatContentProps"]>;
    };
    allowContentSegmentCustom: {
        type: BooleanConstructor;
        default: boolean;
    };
};
export default _default;

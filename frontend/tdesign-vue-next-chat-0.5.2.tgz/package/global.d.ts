/**
 * 该文件为脚本自动生成文件，请勿随意修改。如需修改请联系 PMC
 * https://github.com/TDesignOteam/tdesign-api
 * eslint-disable
 * */
declare module 'vue' {
  export interface GlobalComponents {
    TChat: typeof import('@tdesign-vue-next/chat')['Chat'];
    TChatItem: typeof import('@tdesign-vue-next/chat')['ChatItem'];
    TChatInput: typeof import('@tdesign-vue-next/chat')['ChatInput'];
    TChatSender: typeof import('@tdesign-vue-next/chat')['ChatSender'];
    TChatContent: typeof import('@tdesign-vue-next/chat')['ChatContent'];
    TChatReasoning: typeof import('@tdesign-vue-next/chat')['ChatReasoning'];
    TChatAction: typeof import('@tdesign-vue-next/chat')['ChatAction'];
    TChatLoading: typeof import('@tdesign-vue-next/chat')['ChatLoading'];
    TAttachments: typeof import('@tdesign-vue-next/chat')['Attachments'];
    TChatActionbar: typeof import('@tdesign-vue-next/chat')['ChatActionbar'];
    TChatList: typeof import('@tdesign-vue-next/chat')['ChatList'];
    TChatMarkdown: typeof import('@tdesign-vue-next/chat')['ChatMarkdown'];
    TChatThinking: typeof import('@tdesign-vue-next/chat')['ChatThinking'];
    TChatbot: typeof import('@tdesign-vue-next/chat')['Chatbot'];
    TChatMessage: typeof import('@tdesign-vue-next/chat')['ChatMessage'];
  }
}

export {};
